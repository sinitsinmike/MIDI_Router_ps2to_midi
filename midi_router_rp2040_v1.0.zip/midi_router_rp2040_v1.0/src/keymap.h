#pragma once
#include <Arduino.h>

void handle_hid_code(uint8_t hid_code);