#pragma once
#include <Arduino.h>

void setup_webserial();
void webserial_task();